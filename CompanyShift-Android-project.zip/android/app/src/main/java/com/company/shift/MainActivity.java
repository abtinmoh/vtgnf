package com.company.shift;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
