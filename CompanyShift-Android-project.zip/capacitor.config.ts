import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.company.shift',
  appName: 'Company Shift',
  webDir: 'www'
};

export default config;
